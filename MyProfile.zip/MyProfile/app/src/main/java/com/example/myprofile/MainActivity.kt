package com.example.myprofile

import android.app.AlertDialog
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.view.Menu
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var daftar: Array<String?>
    private lateinit var listView01: ListView
    private var cursor: Cursor? = null
    private var dbCenter: DataHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn = findViewById<Button>(R.id.button2)
        btn.setOnClickListener {
            startActivity(Intent(this, Buat::class.java))
        }

        dbCenter = DataHelper(this)
        refreshList()
    }

    private fun refreshList() {
        val db = dbCenter?.readableDatabase ?: return
        cursor = db.rawQuery("SELECT * FROM biodata", null) // Corrected this line
        daftar = arrayOfNulls(cursor!!.count)

        if (cursor!!.moveToFirst()) {
            for (i in 0 until cursor!!.count) {
                daftar[i] = cursor!!.getString(1) // Get the name from the appropriate column
                cursor!!.moveToNext()
            }
        }

        listView01 = findViewById(R.id.listView1)
        listView01.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, daftar)
        listView01.onItemClickListener = OnItemClickListener { _, _, position, _ ->
            val selection = daftar[position]
            val dialogItems = arrayOf<CharSequence>("Lihat Biodata", "Update Biodata", "Hapus Biodata")

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Pilihan")
            builder.setItems(dialogItems) { _, item ->
                when (item) {
                    0 -> {
                        val intent = Intent(applicationContext, Lihat_Bio::class.java)
                        intent.putExtra("nama", selection)
                        startActivity(intent)
                    }
                    1 -> {
                        val intent = Intent(applicationContext, Update::class.java)
                        intent.putExtra("nama", selection)
                        startActivity(intent)
                    }
                    2 -> {
                        val db = dbCenter?.writableDatabase ?: return@setItems
                        db.execSQL("DELETE FROM biodata WHERE nama = ?", arrayOf(selection))
                        refreshList()
                    }
                }
            }
            builder.create().show()
        }

        cursor?.close() // Close cursor after use
        (listView01.adapter as ArrayAdapter<*>).notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    companion object {
        lateinit var ma: Update
    }
}
